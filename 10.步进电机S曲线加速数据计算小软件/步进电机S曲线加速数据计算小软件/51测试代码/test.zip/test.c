/*------------------------------------------------------------------*/
/* --- STC MCU Limited ---------------------------------------------*/
/* --- STC12C5Axx Series 16-bit Timer Demo -------------------------*/
/* --- Mobile: (86)13922805190 -------------------------------------*/
/* --- Fax: 86-0513-55012956,55012947,55012969 ---------------------*/
/* --- Tel: 86-0513-55012928,55012929,55012966----------------------*/
/* --- Web: www.STCMCU.com -----------------------------------------*/
/* --- Web: www.GXWMCU.com -----------------------------------------*/
/* If you want to use the program or the program referenced in the  */
/* article, please specify in which data and procedures from STC    */
/*------------------------------------------------------------------*/

#include "reg51.h"

#define TIMER_INIT 100


/* define SFR */
sfr AUXR = 0x8e;                    //Auxiliary register

/* define IO */
sbit keyMotor1Forward = P0^2; //���1��ǰ�ź�
sbit keyMotor1Backward = P0^3; //���1����ź�
sbit keyMotor2Forward = P0^4; //���2��ǰ�ź�
sbit keyMotor2Backward= P0^5; //���2����ź�

sbit ioMotor1Direction = P1^0; //���1����
sbit ioMmotor1PWM = P2^6; //���1����
sbit ioMmotor2Direction = P2^0; //���2����
sbit ioMmotor2PWM = P2^1; //���2����

/* define variables */
unsigned long stepInit1;
unsigned long stepPass1;

unsigned long stepInit2;
unsigned long stepPass2;

unsigned int code timerStep[259] = {  0,  153,  771,  1104,  1379,  1589,  1736,  1824,  1862,  1862,  1830,  1777,  1710,
  1635,  1555,  1473,  1393,  1314,  1239,  1168,  1101,  1037,  979,  923,  871,
  824,  780,  738,  699,  664,  630,  599,  570,  543,  518,  494,  472,  452,  432,
  413,  397,  380,  365,  351,  337,  324,  313,  300,  291,  279,  270,  261,  252,
  244,  236,  228,  221,  214,  207,  201,  195,  190,  184,  178,  174,  168,  164,
  160,  155,
  160,  155,  152,  147,  143,  140,  136,  133,  129,  127,  123,  120,  118,  114,
  113,  109,  107,  105,  102,  100,  98,  95,  94,  92,  89,  88,  86,  84,  83,
  81,  79,  77,  77,  74,  73,  72,  70,  69,  68,  66,  65,  64,  63,  62,  60,  60,
  58,  57,  56,  56,  54,  53,  52,  52,  50,  50,  49,  48,  47,  46,  46,  45,  44,
  43,  43,  41,  42,  40,  40,  39,  39,  37,  38,  36,  36,  36,  35,  34,  34,  33,
  33,  32,  31,  32,  30,  30,  30,  29,  29,  28,  28,  27,  27,  26,  26,  26,  25,
  25,  24,  24,  23,  23,  23,  23,  22,  21,  21,  21,  21,  20,  20,  19,  20,  18,
  19,  18,  18,  18,  17,  17,  16,  17,  16,  15,  16,  15,  15,  14,  14,  14,  14,
  14,  13,  13,  12,  12,  13,  11,  12,  11,  11,  11,  11,  10,  10,  10,  9,  10,
  9,  8,  9,  8,  8,  8,  8,  7,  8,  6,  7,  7,  6,  6,  6,  5,  6,  5,  5,  5,  4,
  5,  4,  3,  4,  4,  3,  3,  3,  2,  2,  3,  2,  1,  2,  1,  1,  1,  1,  0,  0,  1};

//-----------------------------------------------

/* Timer0 interrupt routine */
void tm0_isr() interrupt 1 using 1
{
	static unsigned int timerInit;
	unsigned long stepRemain = stepInit1 -  stepPass1;
	if(stepPass1 < 259)
	{
		timerInit += timerStep[stepPass1];
	}
	if(stepRemain < 259)
	{
		timerInit -= timerStep[stepRemain];
	}
	stepPass1++;
	if(stepPass1 == stepInit1)
	{
	    TR0 = 0;
		timerInit = TIMER_INIT;
	}
	TL0 = timerInit;		//���ö�ʱ��ֵ
	TH0 = timerInit>>8;		//���ö�ʱ��ֵ
	ioMmotor1PWM = !ioMmotor1PWM;
}

/* Timer1 interrupt routine */
void tm1_isr() interrupt 3 using 1
{
	static unsigned int timerInit;
	unsigned long stepRemain = stepInit2 -  stepPass2;
	if(stepPass2 < 259)
	{
		timerInit += timerStep[stepPass2];
	}
	if(stepRemain < 259)
	{
		timerInit -= timerStep[stepRemain];
	}
	stepPass2++;
	if(stepPass2 == stepInit2)
	{
	    TR1 = 0;
		timerInit = TIMER_INIT;
	}
	TL1 = timerInit;		//���ö�ʱ��ֵ
	TH1 = timerInit>>8;		//���ö�ʱ��ֵ
	ioMmotor2PWM = !ioMmotor2PWM;
}

//-----------------------------------------------


void Timer0Init(void)		//1΢��@11.0592MHz
{
	AUXR |= 0x80;		//��ʱ��ʱ��1Tģʽ
	TMOD &= 0xF0;		//���ö�ʱ��ģʽ
	TL0 = TIMER_INIT;		//���ö�ʱ��ֵ
	TH0 = TIMER_INIT>>8;		//���ö�ʱ��ֵ
	TF0 = 0;		//���TF0��־
	TR0 = 0;		//��ʱ��0��ʼ��ʱ
	ET0 = 1;                        //enable timer0 interrupt
	EA = 1;                         //open global interrupt switch
}

void Timer1Init(void)		//1΢��@11.0592MHz
{
	AUXR |= 0x40;		//��ʱ��ʱ��1Tģʽ
	TMOD &= 0x10;		//���ö�ʱ��ģʽ
	TL1 = TIMER_INIT;		//���ö�ʱ��ֵ
	TH1 = TIMER_INIT>>8;		//���ö�ʱ��ֵ
	TF1 = 0;		//���TF0��־
	TR1 = 0;		//��ʱ��0��ʼ��ʱ
	ET1 = 1;                        //enable timer0 interrupt
	EA = 1;                         //open global interrupt switch
}

void Delay10ms()		//@11.0592MHz
{
	unsigned char i, j;
	i = 108;
	j = 145;
	do
	{
		while (--j);
	} while (--i);
}



/* main program */
void main()
{
	Timer0Init();
	Timer1Init();
    while(1)
	{
		if(keyMotor1Forward == 0)
		{
			Delay10ms();
			if(keyMotor1Forward == 0 && stepPass1 == stepInit1)
			{
				ioMotor1Direction = 1;
				stepInit1 = 32000;
				stepPass1 = 0;
				TR0 = 1;
			}
		}
		if(keyMotor1Backward == 0)
		{
			Delay10ms();
			if(keyMotor1Backward == 0 && stepPass1 == stepInit1)
			{
				ioMotor1Direction = 0;
				stepInit1 = 32000;
				stepPass1 = 0;
				TR0 = 1;
			}
		}

		if(keyMotor2Forward == 0)
		{
			Delay10ms();
			if(keyMotor2Forward == 0 && stepPass2 == stepInit2)
			{
				ioMmotor2Direction = 1;
				stepInit2 = 3200;
				stepPass2 = 0;
				TR1 = 1;
			}
		}

		if(keyMotor2Backward == 0)
		{
			Delay10ms();
			if(keyMotor2Backward == 0 && stepPass2 == stepInit2)
			{
				ioMmotor2Direction = 0;
				stepInit2 = 3200;
				stepPass2 = 0;
				TR1 = 1;
			}
		}
	};                    
}

