﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using Microsoft.Win32;
namespace EasyChat_Server
{
    class StartItself
    {
        
    }
}
